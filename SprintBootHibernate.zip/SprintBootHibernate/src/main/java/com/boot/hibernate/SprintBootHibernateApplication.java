package com.boot.hibernate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SprintBootHibernateApplication {

	public static void main(String[] args) {
		SpringApplication.run(SprintBootHibernateApplication.class, args);
	}
}
