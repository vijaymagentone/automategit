package com.boot.hibernate;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.sql.DataSource;
import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


public class UserDao {
  
  //@Autowired
  //private SessionFactory _sessionFactory;
  
  //@Autowired
  //DataSource dataSource;
  
  /*private Session getSession() {
	 System.out.println("my data source"+dataSource);
    return _sessionFactory.getCurrentSession();
  }

  public void save(User user) {
    getSession().save(user);
    return;
  }
  
  public void delete(User user) {
    getSession().delete(user);
    return;
  }
  
  @SuppressWarnings("unchecked")
  public List<User> getAll() {
    return getSession().createQuery("from User").list();
  }
  
  public User getByEmail(String email) {
	  System.out.println("in get by email");
    return (User) getSession().createQuery(
        "from User where email = :email")
        .setParameter("email", email)
        .uniqueResult();
  }

  public User getById(long id) {
    return (User) getSession().load(User.class, id);
  }

  public void update(User user) {
    getSession().update(user);
    return;
  }*/
  public Boolean ssocheck(String username,DataSource dataSource)
  {
	  Boolean SsoEnabled=false;
	  try{
		  Connection conn=null;
		  conn=dataSource.getConnection();
		  String search_sql="select * from ne_users where email=?";
		  PreparedStatement ps = conn.prepareStatement(search_sql);
		  ResultSet rs = null;
		  ps.setString(1,username);
		  rs = ps.executeQuery();
			while (rs.next()) {
				if (rs.getString("email").equals(username)){
					if(rs.getInt("org_type_id")==3){
						SsoEnabled=true;
					}
					else{
						SsoEnabled=false;
					}
				}
				else{
					throw new RuntimeException("UserName Not Exist");
				}
			}
		  return SsoEnabled;
	  }catch( Exception e)
		{
			System.out.println(e);
			throw new RuntimeException(e);
		}
  }
  
  public Claims AuthenticateUser(String username,DataSource dataSource) 
 	{
 	   System.out.println("hfjfhgf");
 	   int org_type_id;
 	   String user_name;
	   int user_id;
	   Claims claims;
 		try{
 		    Connection conn=null;
 		    conn=dataSource.getConnection();
 		    System.out.println("connn"+conn);
 		    System.out.println("Datasource1111:"+dataSource);
 		    String search_sql="select * from ne_users where email=?";
 		    PreparedStatement ps = conn.prepareStatement(search_sql);
 		    ResultSet rs = null;
			ps.setString(1,username);
			rs = ps.executeQuery();
			while (rs.next()) {
				org_type_id=rs.getInt("org_type_id");
				user_name=rs.getString("username");
				user_id=rs.getInt("user_id");
			System.out.println("Username:"+user_name);
			System.out.println("Org_type:"+org_type_id);
			List <String>roles=new ArrayList<String>();
			HashMap<String,String> userInfo = new HashMap<String, String>();
			userInfo.put("email", ""+rs.getString("email"));
			userInfo.put("userId", ""+rs.getInt("user_id"));
			userInfo.put("org_id", ""+rs.getInt("org_id"));
			userInfo.put("orgTypeId",""+rs.getInt("org_type_id"));

			String user_group_query="select distinct user_group_id from ne_user_group_users where user_id=?";
			PreparedStatement ps1 = conn.prepareStatement(user_group_query);
			ResultSet rs1=null;
			ps1.setInt(1, user_id);
			rs1=ps1.executeQuery();
			while(rs1.next()){
				System.out.println("in usergroup"+rs1.getInt("user_group_id"));
				String role_query="select a.name, b.role_id from ne_roles a left join ne_role_entity b on a.role_id=b.role_id and b.entity_type='user_groups' where b.entity_id=?";
				PreparedStatement ps2 = conn.prepareStatement(role_query);
				ResultSet rs2=null;
				ps2.setInt(1, rs1.getInt("user_group_id"));
				rs2=ps2.executeQuery();
				while(rs2.next()){
					System.out.println("in roles"+rs2.getString("name"));
					roles.add(rs2.getString("name"));
					
				}
			}
			userInfo.put("Roles",""+ roles);
			System.out.print("ROles=====>"+roles);
			System.out.println("UserInfo Token===>"+userInfo);
			
			String country_name_query="select NAME from ne_country where country_id=?";
			PreparedStatement ps3 = conn.prepareStatement(country_name_query);
			ResultSet rs3=null;
			ps3.setInt(1, rs.getInt("country_id"));
			rs3=ps3.executeQuery();
			String country_name="";
			while(rs3.next()){
				country_name=rs3.getString("NAME");
			}
			
			String user_images_query="select * from ne_images where image_id=?";
			PreparedStatement ps4 = conn.prepareStatement(user_images_query);
			ResultSet rs4=null;
			ps4.setInt(1, rs.getInt("image_id"));
			rs4=ps4.executeQuery();
			String user_tiny_thumb_path="user.png";
			String user_reg_image_path="user.png";
			String user_thumb_path="user.png";
			while(rs4.next()){
				user_tiny_thumb_path=rs4.getString("tiny_thumb_path");
				user_thumb_path=rs4.getString("thumb_path");
				user_reg_image_path=rs4.getString("image_path");
			}
			
			String org_images_query="select * from ne_images where entity_id=? and entity_type='org'";
			PreparedStatement ps5 = conn.prepareStatement(org_images_query);
			ResultSet rs5=null;
			ps5.setInt(1, rs.getInt("org_id"));
			rs5=ps5.executeQuery();
			String org_tiny_thumb_path="diva.png";
			String org_reg_image_path="diva.png";
			String org_thumb_path="diva.png";
			while(rs5.next()){
				user_tiny_thumb_path=rs5.getString("tiny_thumb_path");
				user_thumb_path=rs5.getString("thumb_path");
				user_reg_image_path=rs5.getString("image_path");
			}
			
			List <NeOrgPath>paths=new ArrayList<NeOrgPath>();
			
			String org_path_query="select no.unique_id as org_unique_id,no.org_id,nop.level from ne_org no inner join ne_org_path"
					+" nop on no.org_id=nop.path where nop.org_id=?";
			PreparedStatement ps6 = conn.prepareStatement(org_path_query);
			ResultSet rs6=null;
			ps6.setInt(1, rs.getInt("org_id"));
			rs6=ps6.executeQuery();
			while(rs6.next()){
				NeOrgPath path=new NeOrgPath();
				path.setLevel(rs6.getString("level"));
				path.setOrg_id(rs6.getInt("org_id"));
				path.setOrg_unique_id(rs6.getLong("org_unique_id"));
				paths.add(path);
			}
		   
			
			claims = Jwts.claims().setSubject(user_name);
			claims.put("username", user_name);
	        claims.put("scopes", roles);
	        claims.put("org_type", rs.getInt("org_type_id"));
	        claims.put("user_id", rs.getInt("user_id"));
	        claims.put("Firstname", rs.getString("fname"));
	        claims.put("Lastname", rs.getString("lname"));
	        claims.put("email", rs.getString("email"));
	        claims.put("org_id", rs.getInt("org_id"));
	        claims.put("status", "success");
	        claims.put("country_name",country_name);
	        claims.put("response", "Logged in Sucessfully");
	        claims.put("user_tiny_thumb_path", user_tiny_thumb_path);
	        claims.put("user_thumb_path", user_thumb_path);
	        claims.put("user_reg_image_path", user_reg_image_path);
	        claims.put("org_tiny_thumb_path", org_tiny_thumb_path);
	        claims.put("org_thumb_path", org_thumb_path);
	        claims.put("org_reg_image_path", org_reg_image_path);
	        claims.put("user_unique_id", rs.getLong("unique_id"));
	        claims.put("paths", paths);

	      
	        
	        System.out.println("claims===>"+claims);
	    	return claims;
 		}}
 		catch( Exception e)
 		{
 			System.out.println(e);
 			return null;	
 		}
		return null;	
 	}
}
  	
  