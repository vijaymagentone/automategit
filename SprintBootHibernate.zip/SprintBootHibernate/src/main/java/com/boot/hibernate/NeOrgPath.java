package com.boot.hibernate;

public class NeOrgPath {
	
	private long org_unique_id;
	private int org_id;
	private String level;
	
	public void setOrg_unique_id(long org_unique_id)
	{
		this.org_unique_id=org_unique_id;
	}
	
	public long getOrg_unique_id()
	{
		return org_unique_id;
	}
	
	public void setOrg_id(int org_id)
	{
		this.org_id=org_id;
	}
	
	public long getOrg_id()
	{
		return org_id;
	}
	
	public void setLevel(String level)
	{
		this.level=level;
	}
	
	public String getLevel()
	{
		return level;
	}
	
	

}
