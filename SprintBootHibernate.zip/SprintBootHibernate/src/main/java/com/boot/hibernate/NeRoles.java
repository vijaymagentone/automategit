package com.boot.hibernate;

import java.sql.Date;

public class NeRoles {
	
	private int role_id;
	private String name;
	private String description;
	private int org_id;
	private int created_by;
	private Date created_date;
	private int modified_by;
	private Date modified_date;
	private Long unique_id;
	private int activated;
	private int is_admin;
	private int is_gloabal;
	private int org_type_id;
	
	public int getRole_id(){
		return role_id;
	}
	
	public void serRole_id(int role_id){
		this.role_id=role_id;
	}
	
	public String getName(){
		return name;
	}
	
	public void serName(String name){
		this.name=name;
	}
	
	public String getDescription(){
		return description;
	}
	
	public void setDescription(String description){
		this.description=description;
	}
	
	public int getOrg_id(){
		return org_id;
	}
	
	public void serOrg_id(int org_id){
		this.org_id=org_id;
	}
	
	public int getCreated_by(){
		return created_by;
	}
	
	public void serModified_by(int modifed_by){
		this.modified_by=modifed_by;
	}
	
	public int getModified_by(){
		return modified_by;
	}
	
	public void serModifed_by(int modifed_by){
		this.modified_by=modifed_by;
	}
	
	

}
