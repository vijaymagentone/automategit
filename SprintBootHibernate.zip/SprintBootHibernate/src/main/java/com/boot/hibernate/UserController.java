package com.boot.hibernate;

import static org.springframework.security.extensions.saml2.config.SAMLConfigurer.saml;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.httpclient.HttpStatus;
import org.apache.tomcat.util.http.parser.MediaType;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;



@Controller
public class UserController {

  //@Autowired
  //private UserDao _userDao;
	
  @RequestMapping(value="/")
  public String index()
  {
	  return "login";
  }
  
  @RequestMapping(value="/api/auth/login",method=RequestMethod.POST)
  public String loginCheck(HttpServletRequest request, String username,String password,HttpSession session){
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
	    dataSource.setDriverClassName("com.mysql.jdbc.Driver");
	    dataSource.setUrl("jdbc:mysql://localhost:3306/diva");
	    dataSource.setUsername("root");
	    dataSource.setPassword("admin786");
	    System.out.println("my data source"+dataSource);
	  	UserDao dao=new UserDao();
		Boolean ssocheck=dao.ssocheck(username,dataSource);
		if (ssocheck==true){
			String request_url=request.getRequestURI();
			return "redirect:/api/ssologin/?username="+username;
			
		}
		else{
			return "redirect:/api/jdbclogin/?username="+username;
		}
	  
  }
  
  @RequestMapping(value="/api/ssologin/",method=RequestMethod.GET)
  @ResponseBody
  public ResponseVO ssoLogin(HttpServletRequest request){
	  DriverManagerDataSource dataSource = new DriverManagerDataSource();
	  dataSource.setDriverClassName("com.mysql.jdbc.Driver");
	  dataSource.setUrl("jdbc:mysql://localhost:3306/diva");
	  dataSource.setUsername("root");
	  dataSource.setPassword("admin786");
	  String username = request.getParameter("username");
	  System.out.println("in the sso login");
	  UserDao dao=new UserDao();
	  Claims claims=dao.AuthenticateUser(username,dataSource);
	  DateTime currentTime = new DateTime();
	  String token = Jwts.builder()
		    .setClaims(claims)
		    .setIssuer("https://diva.netenrich.com")
		    .setIssuedAt(currentTime.toDate())
		    .setExpiration(currentTime.plusMinutes(15).toDate())
		    .signWith(SignatureAlgorithm.HS512, "xm8EV6Hy5RMFK4EEACIDAwQus")
		  .compact();
	  System.out.println("token in controller===>"+token);
	  Map<String, String> tokenMap = new HashMap<String, String>();
	  tokenMap.put("token", token);
	  ResponseVO response=new ResponseVO();
	  response.setStatus("success");
	  response.setResponse(token);
	  return response;
  }
  
  @RequestMapping(value="/api/jdbclogin/",method=RequestMethod.GET)
  @ResponseBody
  public ResponseVO jdbcLogin(HttpServletRequest request){
	  DriverManagerDataSource dataSource = new DriverManagerDataSource();
	  dataSource.setDriverClassName("com.mysql.jdbc.Driver");
	  dataSource.setUrl("jdbc:mysql://localhost:3306/diva");
	  dataSource.setUsername("root");
	  dataSource.setPassword("admin786");
	  String username = request.getParameter("username");
	  System.out.println("in the sso login");
	  UserDao dao=new UserDao();
	  Claims claims=dao.AuthenticateUser(username,dataSource);
	  DateTime currentTime = new DateTime();
	  String token = Jwts.builder()
		    .setClaims(claims)
		    .setIssuer("https://diva.netenrich.com")
		    .setIssuedAt(currentTime.toDate())
		    .setExpiration(currentTime.plusMinutes(15).toDate())
		    .signWith(SignatureAlgorithm.HS512, "xm8EV6Hy5RMFK4EEACIDAwQus")
		  .compact();
	  System.out.println("token in controller===>"+token);
	  Map<String, String> tokenMap = new HashMap<String, String>();
	  tokenMap.put("token", token);
	  ResponseVO response=new ResponseVO();
	  response.setStatus("success");
	  response.setResponse(token);
	  return response;
  }
  
  
  
  
  
  @RequestMapping(value="/api/login",method=RequestMethod.POST)
  public ModelAndView loginValidatingApi(HttpServletResponse response, RedirectAttributes redir,HttpServletRequest request,String username,String password) throws JsonGenerationException, JsonMappingException, IOException{
	DriverManagerDataSource dataSource = new DriverManagerDataSource();
    dataSource.setDriverClassName("com.mysql.jdbc.Driver");
    dataSource.setUrl("jdbc:mysql://localhost:3306/diva");
    dataSource.setUsername("root");
    dataSource.setPassword("admin786");
    System.out.println("my data source"+dataSource);
  	System.out .println("username"+username);
  	System.out.println("password"+password);
  	UserDao dao=new UserDao();
	Claims claims=dao.AuthenticateUser(username,dataSource);
	DateTime currentTime = new DateTime();
	String token = Jwts.builder()
	    .setClaims(claims)
	    .setIssuer("https://diva.netenrich.com")
	    .setIssuedAt(currentTime.toDate())
	    .setExpiration(currentTime.plusMinutes(15).toDate())
	    .signWith(SignatureAlgorithm.HS512, "xm8EV6Hy5RMFK4EEACIDAwQus")
	  .compact();
	System.out.println("token in controller===>"+token);
	Map<String, String> tokenMap = new HashMap<String, String>();
    tokenMap.put("token", token);
    //response.setStatus(HttpStatus.SC_ACCEPTED);
    //response.setContentType(MediaType.);
    //mapper.writeValue(response.getWriter(), tokenMap);
    //return tokenMap;
    //response.addHeader("token", token);
    ModelAndView modelAndView=new ModelAndView();
	if (claims.get("org_type").equals(3)){
		//request.setAttribute("token",tokenMap);
		//return "redirect:/partner_login_success";
		modelAndView.setViewName("redirect:/partner_login_success");
		redir.addFlashAttribute("token",token);
	    return modelAndView;
		//return new ModelAndView("partner_login_success","token",token);
		//return tokenMap;
		
	}
	else{
		//request.setAttribute("token",tokenMap);
		//return "redirect:/normal_login_success";
		modelAndView.setViewName("redirect:/normal_login_success");
		redir.addFlashAttribute("token",token);
	    return modelAndView;
		//return new ModelAndView( "normal_login_success","token",token);
		//return token;
	}
	
  	
  }
  
  @RequestMapping("/partner_login_success")
  public String partner_login_success(@ModelAttribute("token")String token,Model model){
	  //System.out.println("tokren in partner"+token);
	  //model.addAttribute("token",token);
	  return "Hi Partner User....Your access token..."+token;
	 // return "partner_login_success";
	  //return new ModelAndView( "partner_login_success","token",token);
  }
  
  @RequestMapping("/normal_login_success")
  public String normal_login_success(@ModelAttribute("token") String  token,Model model){
	  System.out.println("tokren in normal"+token);
	  //model.addAttribute("token",token);
	  return "Hi Diva User....Your access token..."+token;
	  //return new ModelAndView( "normal_login_success","token",token);
      //return "normal_login_success";
  }
  
  /*@RequestMapping(value="/delete")
  @ResponseBody
  public String delete(long id) {
    try {
      User user = new User(id);
      _userDao.delete(user);
    }
    catch(Exception ex) {
      return ex.getMessage();
    }
    return "User succesfully deleted!";
  }
  
  @RequestMapping(value="/get-by-email")
  @ResponseBody
  public String getByEmail(String email) {
	System.out.println("email:"+email);
    String userId;
    try {
      User user = _userDao.getByEmail(email);
      userId = String.valueOf(user.getId());
    }
    catch(Exception ex) {
      return "User not found";
    }
    return "The user id is: " + userId;
  }

  @RequestMapping(value="/save")
  @ResponseBody
  public String create(String email, String name) {
    try {
      User user = new User(email, name);
      _userDao.save(user);
    }
    catch(Exception ex) {
      return ex.getMessage();
    }
    return "User succesfully saved!";
  }
*/
} // class UserController